const parentEl = document.querySelector(".parent-div-products");
const pagEl = document.querySelector(".numList");
let stateProd = {
  pageid: "",
};
let num = 0;
const getProducts = async function () {
  const products = await fetch("https://fakestoreapi.com/products");
  const result = await products.json();
  num = result.length;

  renderMarkup(result, true);
};
var url = window.location.pathname;
const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const category = urlParams.get("category");
console.log(category);

const renderMarkup = function (result, value) {
  const markup = generateMarkuploop();
  parentEl.innerHTML = "";
  parentEl.insertAdjacentHTML("afterbegin", markup);
  function generateMarkuploop() {
    const Mark = result.map((res) => generateMarkup(res)).join("");
    return Mark;
  }
  function generateMarkup(result) {
    return ` <div class="block-post-products dis" id="${result.id}">
<img class="products-img" src="${result.image}" alt="" />
<div class="img-txt-products"><span>${result.title}</span></div>
</div>`;
  }
  return markup;
};

const getCategoryProduct = async function (category) {
  console.log(category);
  const products = await fetch(
    `https://fakestoreapi.com/products/category/${category}`
  );
  const result = await products.json();

  let val = renderMarkup(result, false);

  return val;
};
const categoryProduct = function (e) {
  let strr = "";
  if (e.target.classList.contains("prod")) {
    let checkedArr = getAllCheckedSiblings(e.target);
    if (!checkedArr.length == 0) {
      const arr = checkedArr.map(async function (elem) {
        result = await getCategoryProduct(elem.getAttribute("name"));
        return result;
      });
      let promises = [];
      for (let i = 0; i < arr.length; i++) {
        promises.push(arr[i]);
      }
      Promise.all(promises).then(function (results) {
        parentEl.innerHTML = "";
        let markup = results.join("");
        parentEl.insertAdjacentHTML("afterbegin", markup);
      });
    } else {
      getProducts();
    }
  }
};

function getAllCheckedSiblings(elem) {
  var sibs = [];
  elemp = elem.parentNode.firstChild;
  do {
    if (elemp.checked) {
      sibs.push(elemp);
    }
  } while ((elemp = elemp.nextSibling));
  return sibs;
}

const facets = document.querySelector(".categories");
facets.addEventListener("click", categoryProduct);

const prodContainer = document.querySelector(".parent-div-products");
prodContainer.addEventListener("click", function (e) {
  const id = e.target.closest(".block-post-products").getAttribute("id");
  window.location.href = `product.html?product=${id}`;
});
if (category == null) {
  getProducts();
} else {
  getCategoryProduct(category);
}
